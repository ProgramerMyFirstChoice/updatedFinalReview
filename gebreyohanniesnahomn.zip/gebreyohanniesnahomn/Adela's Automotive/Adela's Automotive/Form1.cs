﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Adela_s_Automotive
{
    public partial class Form1 : Form
    {
        /*
         * Nahom Gebreyohannies
         * 
         * code for Final Project
         * 
         * Instructor Christy Hernadez
         * Date 03/23/2018
         */

        /*Please compare your original with this copy to find changes
               * and review comments I added*/

        public Form1()
        {
            InitializeComponent();
        }

        // Create object for Service class
        Service serv = new Service();

        // Create object for Validation class
        Validator valide = new Validator();
    

        // Button click to use calculate and display the result
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Declare variables
            double total = 0;
            double tax = 0;
            double part = 0;
            double service = 0;
            double labor = 0;
            double costOfLabor = 0;
            double costOfLaborAndService = 0;
            // When the checkbox selected take cost of service
            // And add the value to service variable 
            // With each checkbox selected caculate the cost of oil Lube change
            //use your class properties instead of variables
            if (chkOil.Checked)
            {
                serv.Services += serv.Oil;
            }
            if (chkLube.Checked)
            {
                service += serv.Lube;
            }

            // With each checkbox selected calculate the cost of misc services

            if (chkInspection.Checked)
            {
                service += serv.Inspection;
            }

            if (chkMuffler.Checked)
            {
                service += serv.ReplaceMuffler;
            }

            if (chkTire.Checked)
            {
                service += serv.TireRotation;
            }

            // With each checkbox selected calculate the cost of flushes
            if (chkRadiator.Checked)
            {
                service += serv.RadiatorFlush;
            }

            if (chkTransmission.Checked)
            {
                service += serv.TransissionFlush;
            }

            // Check for reqiured value of labor hour
            if (valide.IsPresent(txtLabor))
            {
                // Check the labor hour is above 0 and less than 8 hour
                if (valide.IsWithinRange(txtLabor, 0, 8))
                {             
                // check the labor hour and part whether it is double
                if (valide.IsDouble(txtLabor) && valide.IsDouble(txtPart))
                {
                    // Collect and assign user input to labor hour variable
    //use class properties
                     serv.Labor = Convert.ToDouble(txtLabor.Text);
                    
                        // Calculate the cost of the labor hour
                        // using Service class method and assign it                   
                       
                        serv.Labor = serv.CostOfLabor(serv.Labor);
                        // Added the selected checkbox service to costOfLabor 
                        // to find the to cost of srvice and labor hour spent on service
                        serv.Services = serv.Services + serv.Labor;
                        // change user input from string to double
                        serv.Part = double.Parse(txtPart.Text);
                        // Get the calculated tax
                        serv.TaxDue= (serv.Part * .06);

                       

                    // Calculate the total cost
                    serv.Total = serv.Services + serv.Part + serv.TaxDue;

                    //display the cost of labor and service
                    //parts, tax on the parts and grand total
                    txtService.Text = serv.Total.ToString("c2");
                    txtSummaryParts.Text = serv.Part.ToString("c2");
                    txtTax.Text = serv.TaxDue.ToString("c2");
                    txtTotal.Text = serv.Total.ToString("c2");
                }
                }
            }
        }

        // Button click clear all the selected checkbox and the value of textbox
        private void btnClear_Click(object sender, EventArgs e)
        {
            chkOil.Checked = false;
            chkLube.Checked = false;
            chkRadiator.Checked = false;
            chkTransmission.Checked = false;
            chkInspection.Checked = false;
            chkMuffler.Checked = false;
            chkTire.Checked = false;
            txtPart.Clear();
            txtLabor.Clear();
            txtService.Clear();
            txtSummaryParts.Clear();
            txtTax.Clear();
            txtTotal.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Close the application
            this.Close();
        }

    }
    #region Service class and Validator class
    class Validator
    {
        // Fields
        private double number;

        public string Title { get; set; }
      
        public bool IsPresent(TextBox textBox)
        {
            if (textBox.Text == "")
            {
                MessageBox.Show(textBox.Tag + " is a required field.", Title);
                textBox.Focus();
                return false;
            }
            return true;
        }
        public bool IsDouble(TextBox textBox)
        {
            if (double.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(textBox.Tag + " must be a number value.", Title);
                textBox.Focus();
                return false;
            }
        }    
    
        // Method that check whether the user input is with specified value
        public bool IsWithinRange(TextBox textBox, decimal min, decimal max)
        {
            decimal number = Convert.ToDecimal(textBox.Text);
            if (number <= min || number > max)
            {
                MessageBox.Show(textBox.Tag + " must be greater than " + min + " and less than " + max + ".", Title);
                textBox.Focus();
                return false;
            }
            return true;
        }
    }

    class Service
    {
        // Private Fields for Service class
        private double _total;
        private double _part;
        private double _services;
        private double _labor;
        public double TaxDue { get; set; }
        // Constant fields
        public const double COSTOFLABOR = 80.00;
        public const double TAX = 0.06;

        // Default constructor
        public Service()
        {

        }
        // Properties
        public double Total { get { return _total; } set { _total = value; } }

        public double Part { get { return _part; } set { _part = value; } }

        public double Services { get { return _services; } set { _services = value; } }

        public double Labor { get { return _labor; } set { _labor = value; } }

        public double Oil { get; set; } = 26.00;
        public double Lube { get; } = 18.00;
        public double Inspection { get; } = 15.00;
        public double ReplaceMuffler { get; } = 100.00;
        public double TireRotation { get; } = 20.00;
        public double RadiatorFlush { get; } = 30.00;
        public double TransissionFlush { get; } = 80.00;


        // Method that calculate the cost of labor per hour
        public double CostOfLabor(double labor)
        {  
            labor = labor * COSTOFLABOR;
            return labor;
        }

        public double FlushTotal()
        {
            double flush = 0;
            return flush;
        }



    }
    #endregion
}
