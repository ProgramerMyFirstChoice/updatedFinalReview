﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Adela_s_Automotive
{
    public partial class Form1 : Form
    {
        /*
         * Nahom Gebreyohannies
         * 
         * code for Final Project
         * 
         * Instructor Christy Hernadez
         * Date 03/23/2018
         */

        public Form1()
        {
            InitializeComponent();
        }

        // Create object for Service class
        Service serv = new Service();

        // Create object for Validation class
        Validator valide = new Validator();
        
        // Button click to use calculate and display the result
        private void btnCalculate_Click(object sender, EventArgs e)
        {
 
            //method call to set all 
            //calculating values to zero
            //just in case it's not users 
            //first click
            MakeZero();


            //check if ServicesRendered is greater than zero
            //if it is not > 0 then the user did not select a service
            if (GetServicesChecked() > 0)
            {
                if (String.IsNullOrEmpty(txtPartsPrice.Text))//if the textbox for parts is empty
                {
                    //make the property 0
                    serv.Parts = 0.0;
                }
                else if (valide.IsDouble(txtPartsPrice))//if user did enter a value check if it's a double
                {
                    CalculatePartsTax();//method call parts tax
                }
                if (valide.IsPresent(txtLabor))//labor required
                {
                    if (valide.IsDouble(txtLabor))//labor is double
                    {
                        CalculateLaborServices();//method call labor and services
                        DisplayCalculations();//method call to display all calculations
                    }
                }
            }
            else
            {
                MessageBox.Show("Select a Service.");
            }
        }

        //Display total values to text boxes
        public void DisplayCalculations()
        {

            txtServicenLabor.Text = serv.ServiceAndLabor.ToString("c2");
            txtPartsTotal.Text = serv.Parts.ToString("c2");
            txtTax.Text = serv.TaxDue.ToString("c2");
            txtTotal.Text = serv.Total.ToString("c2");
        }// end

        // Button click clear all the selected checkbox and the value of textbox
        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearAll();
        }
        //checks checkboxes for checks
        //accumulate services rendered
        public double GetServicesChecked()
        {
            //check 
            if (chkBxOilChange.Checked)
            {
                //add it to services rendered
                serv.ServicesRendered += serv.OilChange;
            }
            if (chkbxLube.Checked)
            {
                //add it to services rendered
                serv.ServicesRendered += serv.LubeJob;
            }
            if (chkbxMufflerReplacement.Checked)
            {
                //add it to services rendered
                serv.ServicesRendered += serv.MufflerReplacement;
            }
            if (chkbxRadiatorFlush.Checked)
            {
                //add it to services rendered
                serv.ServicesRendered += serv.RadiatorFlush;
            }
            if (chkbxTransmissionFLush.Checked)
            {
                //add it to services rendered
                serv.ServicesRendered += serv.TransmissionFlush;
            }
            if (chkbxInspection.Checked)
            {
                //add it to services rendered
                serv.ServicesRendered += serv.Inspection;
            }
            if (chkbxTireRotation.Checked)
            {
                //add it to services rendered
                serv.ServicesRendered += serv.TireRotation;
            }
            return serv.ServicesRendered;
        }

        //add labor and services rendered
        public void CalculateLaborServices()
        {
            serv.LaborHours = double.Parse(txtLabor.Text);
            serv.LaborCharge = serv.LaborHours * Service.LaborPerHour;//calculate labor total
            serv.ServiceAndLabor = serv.ServicesRendered + serv.LaborCharge;//calculate services and labor

            serv.Total = serv.ServiceAndLabor + serv.Parts + serv.TaxDue;
        }

        //calculate tax if txtPart has value
        public void CalculatePartsTax()
        {
            serv.Parts = double.Parse(txtPartsPrice.Text);
            serv.TaxDue = (serv.Parts * Service.TAX);//calculate parts tax
        }

        // Method to clear the selected checkbox and the value in the textbox
        private void ClearAll()
        {
            chkBxOilChange.Checked = false;
            chkbxLube.Checked = false;
            chkbxRadiatorFlush.Checked = false;
            chkbxTransmissionFLush.Checked = false;
            chkbxInspection.Checked = false;
            chkbxMufflerReplacement.Checked = false;
            chkbxTireRotation.Checked = false;
            txtPartsPrice.Clear();
            txtLabor.Clear();
            txtServicenLabor.Clear();
            txtPartsTotal.Clear();
            txtTax.Clear();
            txtTotal.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Close the application
            this.Close();
        }

        //reset all calculating properties to zero
        public void MakeZero()
        {
            serv.ServicesRendered = 0;
            serv.Parts = 0;
            serv.TaxDue = 0;
            serv.LaborHours = 0;
            serv.LaborCharge = 0;
            serv.ServiceAndLabor = 0;
            serv.Total = 0;
        }
    }
    #region Service class and Validator class
    class Validator
    {
        // Fields
        private string title = "Entry Error";

        // Title property
        public string Title
        {
            get
            {
                return title;
            }
            set
            {
                title = value;
            }
        }

        // Method for presence of value in textbox
        public bool IsPresent(TextBox textBox)
        {
            if (textBox.Text == "")
            {
                MessageBox.Show(textBox.Tag + " is a required field.", Title);
                textBox.Focus();
                return false;
            }
            return true;
        }

        // Method that check whether the user input is double
        public bool IsDouble(TextBox textBox)
        {
            if (Double.TryParse(textBox.Text, out double number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(textBox.Tag + " must be a number or decimal value.", Title);
                textBox.Focus();
                return false;
            }
        }

        // Method that check whether the user input is decimal
        public bool IsDecimal(TextBox textBox)
        {
            if (Decimal.TryParse(textBox.Text, out decimal number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(textBox.Tag + " must be a decimal value.", Title);
                textBox.Focus();
                return false;
            }
        }

        // Method that check whether the user input is integer
        public bool IsInt32(TextBox textBox)
        {
            if (Int32.TryParse(textBox.Text, out int number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(textBox.Tag + " must be an integer.", Title);
                textBox.Focus();
                return false;
            }
        }

        // Method that check whether the user input is with specified value
        public bool IsWithinRange(TextBox textBox, decimal min, decimal max)
        {
            decimal number = Convert.ToDecimal(textBox.Text);
            if (number <= min || number > max)
            {
                MessageBox.Show(textBox.Tag + " must be greater than " + min + " and less than " + max + ".", Title);
                textBox.Focus();
                return false;
            }
            return true;
        }
    }

    class Service
    {
        // Private Fields for Service class
        private double _total;
        private double _part;
        private double _servicesRendered;
        private double _laborCharge;
        private double _tax;
        private double _laborHours;
        private double _serviceAndLabor;


        // Constant fields
        public const double LaborPerHour = 80.00;
        public const double TAX = 0.06;

        // Default constructor
        public Service()
        {

        }

        // Properties
        public double Total { get { return _total; } set { _total = value; } }

        public double Parts { get { return _part; } set { _part = value; } }

        public double LaborCharge { get { return _laborCharge; } set { _laborCharge = value; } }

        public double TaxDue { get { return _tax; } set { _tax = value; } }

        public double LaborHours { get { return _laborHours; } set { _laborHours = value; } }

        public double ServicesRendered { get { return _servicesRendered; } set { _servicesRendered = value; } }

        public double ServiceAndLabor { get { return _serviceAndLabor; } set { _serviceAndLabor = value; } }

        // Properties for Checkbox fields
        public double OilChange { get;} = 26.00;
        public double LubeJob { get; } = 18.00;
        public double Inspection { get; } = 15.00;
        public double MufflerReplacement { get; } = 100.00;
        public double TireRotation { get; } = 20.00;
        public double RadiatorFlush { get; } = 30.00;
        public double TransmissionFlush { get; } = 80.00;    
    }
    #endregion
}
